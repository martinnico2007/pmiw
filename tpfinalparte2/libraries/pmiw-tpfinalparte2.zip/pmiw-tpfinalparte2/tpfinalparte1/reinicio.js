function botonReinicio() {
fill(139,0,0);
if(dist(mouseX, mouseY, 480, 350)< 30){
fill(178,34,34);
 }
ellipse(480,350,60,60);
}
function clickBoton(){
return dist(mouseX, mouseY, 480, 350)< 30;

}

function botonReinicio2() {
fill(139,0,0);
if(dist(mouseX, mouseY, 480, 440)< 30){
fill(178,34,34);
 }
ellipse(480,440,60,60);
}
function clickBoton2(){
return dist(mouseX, mouseY, 480, 440)< 30;

}
