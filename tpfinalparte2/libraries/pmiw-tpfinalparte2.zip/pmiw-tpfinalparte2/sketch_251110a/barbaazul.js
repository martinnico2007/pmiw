class barbaazul {
  constructor(){
    this.PosY;
    this.PosX;
  }
}
